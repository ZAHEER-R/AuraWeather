// periphery:ignore:all
// swiftlint:disable:this file_name
// swiftlint:disable all
// swift-format-ignore-file
// swiftformat:disable all
#if hasFeature(InternalImportsByDefault)
public import Foundation
#else
import Foundation
#endif
// MARK: - Swift Bundle Accessor for Frameworks
private class BundleFinder {}
extension Foundation.Bundle {
/// Since AuraWeather is a application, the bundle for classes within this module can be used directly.
    nonisolated static let module = Bundle(for: BundleFinder.self)
}
// MARK: - Objective-C Bundle Accessor
@objc
public final class AuraWeatherResources: NSObject {
@objc public nonisolated class var bundle: Bundle {
    return .module
}
}
// swiftformat:enable all
// swiftlint:enable all